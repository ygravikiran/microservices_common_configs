package com.virtusa.banking.customerms.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.virtusa.banking.customerms.models.Customer;
import com.virtusa.banking.customerms.services.CustomerService;

@RestController
public class CustomerController {
	@Autowired
	private CustomerService customerService;
	
	//saving the customer details
	@CrossOrigin("*")
	@PostMapping("/addcustomer")
	public @ResponseBody Customer addCustomer(@RequestBody Customer customer)
	{
		return this.customerService.saveCustomer(customer);
	}
	
	//retrieval 
	
	@CrossOrigin("*")
	@GetMapping("/getallcustomers")
	public List<Customer> findAllCustomers()
	{
		return this.customerService.getAllCustomers();
	}
	
	//retrieval  by id
	
		@CrossOrigin("*")
		@GetMapping("/getcustomerbyid/{customerId}")
		public Customer findCustomerById(@PathVariable("customerId") long customerId)
		{
			return this.customerService.getCustomerById(customerId);
		}
		
		@CrossOrigin("*")
		@DeleteMapping("/deletecustomerbyid/{id}")
		public boolean deleteCustomerById(@PathVariable("id") long id)
		{
			this.customerService.deleteCustomerById(id);
			boolean status=false;
			if(customerService.getCustomerById(id)==null)
				status=true;
			return status;
		}
		
		
		@CrossOrigin("*")
		@PutMapping("/updatecustomer")
		public @ResponseBody Customer updateCustomer(@RequestBody Customer customer)
		{
			return customerService.updateCustomer(customer);
		}
			
		
	

}
